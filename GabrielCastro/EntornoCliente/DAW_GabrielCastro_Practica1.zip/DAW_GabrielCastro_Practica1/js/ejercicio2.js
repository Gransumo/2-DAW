
document.addEventListener("DOMContentLoaded", () => {
	var buttom = document.getElementById("exe2");
	buttom.addEventListener("click", () => {
		var a = 20;
		var b = 8;
		alert (a + b);
	});
})
